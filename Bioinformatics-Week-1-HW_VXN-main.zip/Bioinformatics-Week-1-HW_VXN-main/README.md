# Bioinformatics-Week-1-HW_VXN 

                           [{
		"Name": "Gryllus veletis mitochondrion, complete genome",
		"Length": 15686,
		"accession number": "NC_057053"
	}, {
		"Name": "Natula pravdini mitochondrion, complete genome",
		"Length": 15817,
		"accession number": "NC_050742"
	}, {
		"Name": "Svistella anhuiensis mitochondrion, complete genome",
		"Length": 16494,
		"accession number": "MG701238"
	}, {
		"Name": "Myrmecophilus antilucanus isolate AG082C3 cytochrome b (cytb) gene, partial cds; mitochondrial",
		"Length": 635,
		"accession number": "MN065093"
	}, {
		"Name": "Myrmophilellus pilipes isolate mun2-r1-3 cytochrome b (cytb) gene, partial cds; mitochondrial",
		"Length": 632,
		"accession number": "MN065059"
	}]

